const Storage = {
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.log('Ошибка сохранения:', error);
            return false;
        }
    },

    get(key) {
        try {
            const value = localStorage.getItem(key);
            return value ? JSON.parse(value) : null;
        } catch (error) {
            console.log('Ошибка чтения:', error);
            return null;
        }
    },

    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.log('Ошибка удаления:', error);
            return false;
        }
    },

    saveCart(cartItems) {
        return this.set('cart', cartItems);
    },

    loadCart() {
        return this.get('cart') || [];
    }
};

export default Storage;