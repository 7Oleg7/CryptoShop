import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

const API_URL = 'http://localhost:5082';

function useProducts() {
    const productsQuery = useQuery({
        queryKey: ['products'],
        queryFn: async () => {
            try {
                const response = await axios.get(`${API_URL}/api/products`);
                console.log('Products loaded:', response.data); // Для отладки
                return response.data;
            } catch (error) {
                console.error('Error loading products:', error);
                throw error;
            }
        },
        staleTime: 10000,
        cacheTime: 15000,
        retry: 1
    });

    return {
        products: productsQuery.data || [],
        isLoading: productsQuery.isLoading,
        isError: productsQuery.isError,
        error: productsQuery.error
    };
}

export default useProducts;