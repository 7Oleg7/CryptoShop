import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Storage from '../utils/storage';
import { CartContext } from './CartContext';

const CartProvider = ({ children }) => {
    const queryClient = useQueryClient();

    const { data: cartItems = [], isLoading } = useQuery({
        queryKey: ['cart'],
        queryFn: async () => {
            const savedCart = await Storage.loadCart();
            return savedCart || [];
        }
    });

    const { mutate: saveCart } = useMutation({
        mutationFn: async (newCart) => {
            await Storage.saveCart(newCart);
            return newCart;
        },
        onSuccess: (newCart) => {
            queryClient.setQueryData(['cart'], newCart);
        }
    });

    const addToCart = (product, quantity = 1) => {
        const newCart = [...cartItems];
        const existingItem = newCart.find(item => item.product.id === product.id);
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            newCart.push({ product, quantity });
        }
        saveCart(newCart);
    };

    const removeFromCart = (productId) => {
        const newCart = cartItems.filter(item => item.product.id !== productId);
        saveCart(newCart);
    };

    const updateQuantity = (productId, quantity) => {
        if (quantity < 1) {
            removeFromCart(productId);
            return;
        }
        const newCart = cartItems.map(item =>
            item.product.id === productId ? { ...item, quantity } : item
        );
        saveCart(newCart);
    };

    const clearCart = () => {
        saveCart([]);
    };

    const getCartTotal = () => {
        return cartItems.reduce((total, item) => 
            total + (item.product.price * item.quantity), 0
        );
    };

    const getCartCount = () => {
        return cartItems.reduce((count, item) => count + item.quantity, 0);
    };

    return (
        <CartContext.Provider value={{
            cartItems,
            isLoading,
            addToCart,
            removeFromCart,
            updateQuantity,
            clearCart,
            getCartTotal,
            getCartCount
        }}>
            {children}
        </CartContext.Provider>
    );
};

export default CartProvider;