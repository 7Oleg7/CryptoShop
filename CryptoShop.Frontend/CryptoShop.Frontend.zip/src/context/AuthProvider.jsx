import React, { useState, useEffect } from 'react';
import { AuthContext } from './AuthContext';
import axios from 'axios';
import Storage from '../utils/storage';

const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(false);
    const [initialLoading, setInitialLoading] = useState(true);

    useEffect(() => {
        loadStoredUser();
    }, []);

    async function loadStoredUser() {
        try {
            const savedUser = await Storage.get('user');
            if (savedUser) {
                setUser(savedUser);
            }
        } catch (error) {
            console.log('Ошибка загрузки пользователя:', error);
        } finally {
            setInitialLoading(false);
        }
    }

    async function saveUser(userData) {
        if (userData) {
            await Storage.set('user', userData);
        } else {
            await Storage.remove('user');
        }
    }

    const login = async (email, password) => {
        try {
            setLoading(true);
            const response = await axios.post('http://localhost:5082/api/auth/login', {
                email,
                password
            });
            
            const userData = response.data;
            setUser(userData);
            await saveUser(userData);
            
            return { success: true };
        } catch (error) {
            return { 
                success: false, 
                error: error.response?.data || 'Ошибка входа' 
            };
        } finally {
            setLoading(false);
        }
    };

    const register = async (userData) => {
        try {
            setLoading(true);
            const response = await axios.post('http://localhost:5082/api/auth/register', userData);
            
            const newUser = response.data;
            setUser(newUser);
            await saveUser(newUser);
            
            return { success: true };
        } catch (error) {
            return { 
                success: false, 
                error: error.response?.data || 'Ошибка регистрации' 
            };
        } finally {
            setLoading(false);
        }
    };

    const logout = async () => {
        setUser(null);
        await saveUser(null);
    };

    const updateProfile = async (userId, profileData) => {
        try {
            setLoading(true);
            const response = await axios.put(`http://localhost:5082/api/auth/profile/${userId}`, profileData);
            
            const updatedUser = response.data;
            setUser(updatedUser);
            await saveUser(updatedUser);
            
            return { success: true };
        } catch (error) {
            return { 
                success: false, 
                error: error.response?.data || 'Ошибка обновления' 
            };
        } finally {
            setLoading(false);
        }
    };

    return (
        <AuthContext.Provider value={{
            user,
            loading,
            initialLoading,
            login,
            register,
            logout,
            updateProfile
        }}>
            {children}
        </AuthContext.Provider>
    );
};

export default AuthProvider;