import React from 'react';
import { Spinner } from 'react-bootstrap';

function Loading() {
    return (
        <div className="text-center mt-5">
            <Spinner animation="border" variant="primary" />
            <p className="mt-2">Загрузка...</p>
        </div>
    );
}

export default Loading;