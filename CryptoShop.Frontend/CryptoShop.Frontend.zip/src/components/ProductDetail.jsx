import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Form } from 'react-bootstrap';
import { useQuery } from '@tanstack/react-query';
import { useCart } from '../hooks/useCart';
import { useAuth } from '../hooks/useAuth';
import axios from 'axios';
import ReviewList from './ReviewList';

function ProductDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { addToCart } = useCart();
    const { user } = useAuth();
    const [quantity, setQuantity] = useState(1);

    const { data: product, isLoading } = useQuery({
        queryKey: ['product', id],
        queryFn: async () => {
            const response = await axios.get('http://localhost:5082/api/products/' + id);
            return response.data;
        }
    });

    function handleAddToCart() {
        addToCart(product, quantity);
        navigate('/cart');
    }

    if (isLoading) return <div className="text-center mt-5">Загрузка...</div>;
    if (!product) return <div className="text-center mt-5">Товар не найден</div>;

    return (
        <Container className="mt-4">
            <Row>
                <Col md={6}>
                    <img 
                        src={product.imageUrl || 'https://via.placeholder.com/400'} 
                        alt={product.name}
                        className="img-fluid"
                    />
                </Col>
                
                <Col md={6}>
                    <Card>
                        <Card.Body>
                            <h2>{product.name}</h2>
                            <p className="text-muted">{product.category?.name}</p>
                            <h3 className="text-success">${product.price}</h3>
                            <p>{product.description}</p>
                            <p>В наличии: {product.stock} шт.</p>
                            
                            <Form.Group className="mb-3">
                                <Form.Label>Количество</Form.Label>
                                <Form.Control
                                    type="number"
                                    min="1"
                                    max={product.stock}
                                    value={quantity}
                                    onChange={(e) => setQuantity(parseInt(e.target.value))}
                                    style={{ width: '100px' }}
                                />
                            </Form.Group>
                            
                            <Button variant="success" onClick={handleAddToCart}>
                                В корзину
                            </Button>
                            <Button variant="secondary" className="ms-2" onClick={() => navigate('/')}>
                                Назад
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            
            {user && <ReviewList productId={product.id} userId={user.id} />}
        </Container>
    );
}

export default ProductDetail;