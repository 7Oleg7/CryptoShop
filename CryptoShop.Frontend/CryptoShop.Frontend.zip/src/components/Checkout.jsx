import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap';
import { ethers } from 'ethers';
import { useCart } from '../hooks/useCart';
import { useAuth } from '../hooks/useAuth';
import axios from 'axios';

const CONTRACT_ABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "buyer",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "orderId",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			}
		],
		"name": "PurchaseCompleted",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "getBalance",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "orderId",
				"type": "string"
			}
		],
		"name": "purchase",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	}
];

const CONTRACT_ADDRESS = "0x3D3C75f8A81eFe7D53b4374d1052c4657F4F6a29";

function Checkout() {
    const navigate = useNavigate();
    const { cartItems, getCartTotal, clearCart } = useCart();
    const { user } = useAuth();

    const [address, setAddress] = useState(user?.address || '');
    const [phone, setPhone] = useState(user?.phone || '');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    if (!user) {
        navigate('/login');
        return null;
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const orderData = {
                userId: user.id,
                totalAmount: getCartTotal(),
                deliveryAddress: address,
                phone: phone,
                items: cartItems.map(item => ({
                    productId: item.product.id,
                    quantity: item.quantity,
                    price: item.product.price
                }))
            };

            const orderResponse = await axios.post('http://localhost:5082/api/orders/create', orderData);
            const orderId = orderResponse.data.orderId;
            const orderNumber = orderResponse.data.orderNumber;

            if (!window.ethereum) {
                throw new Error('Установите MetaMask');
            }

            await window.ethereum.request({ method: 'eth_requestAccounts' });
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
            const ethAmount = ethers.utils.parseEther((getCartTotal() * 0.001).toString());
            const transaction = await contract.purchase(orderNumber, { value: ethAmount });
            const receipt = await transaction.wait();

            await axios.post('http://localhost:5082/api/orders/confirm-payment', {
                orderId: orderId,
                transactionHash: receipt.transactionHash
            });

            clearCart();
            alert('Оплата прошла успешно! Заказ оформлен.');
            navigate('/profile');
        } catch (err) {
            setError(err.message || 'Ошибка при оплате');
        } finally {
            setLoading(false);
        }
    }

    return (
        <Container className="mt-4">
            <h2>Оформление заказа</h2>
            
            <Row>
                <Col md={7}>
                    <Card>
                        <Card.Body>
                            <Card.Title>Данные доставки</Card.Title>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Адрес доставки</Form.Label>
                                    <Form.Control
                                        type="text"
                                        value={address}
                                        onChange={(e) => setAddress(e.target.value)}
                                        required
                                    />
                                </Form.Group>
                                
                                <Form.Group className="mb-3">
                                    <Form.Label>Телефон</Form.Label>
                                    <Form.Control
                                        type="tel"
                                        value={phone}
                                        onChange={(e) => setPhone(e.target.value)}
                                        required
                                    />
                                </Form.Group>
                                
                                {error && <Alert variant="danger">{error}</Alert>}
                                
                                <Button type="submit" variant="success" disabled={loading}>
                                    {loading ? 'Обработка...' : `Оплатить $${getCartTotal().toFixed(2)}`}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                
                <Col md={5}>
                    <Card>
                        <Card.Body>
                            <Card.Title>Ваш заказ</Card.Title>
                            {cartItems.map(item => (
                                <div key={item.product.id} className="d-flex justify-content-between mb-2">
                                    <span>{item.product.name} x {item.quantity}</span>
                                    <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                                </div>
                            ))}
                            <hr />
                            <div className="d-flex justify-content-between">
                                <strong>Итого:</strong>
                                <strong>${getCartTotal().toFixed(2)}</strong>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default Checkout;