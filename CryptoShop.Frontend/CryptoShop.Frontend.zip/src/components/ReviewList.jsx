import React, { useState } from 'react';
import { Card, Form, Button, Alert } from 'react-bootstrap';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

function ReviewList({ productId, userId }) {
    const [rating, setRating] = useState(5);
    const [comment, setComment] = useState('');
    const [success, setSuccess] = useState('');
    const queryClient = useQueryClient();

    const { data: reviews = [] } = useQuery({
        queryKey: ['reviews', productId],
        queryFn: async () => {
            const response = await axios.get('http://localhost:5082/api/reviews/product/' + productId);
            return response.data;
        }
    });

    const { mutate: addReview, isPending } = useMutation({
        mutationFn: async () => {
            await axios.post('http://localhost:5082/api/reviews', {
                productId, userId, rating, comment
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['reviews', productId] });
            setComment('');
            setSuccess('Отзыв добавлен!');
            setTimeout(() => setSuccess(''), 3000);
        }
    });

    function renderStars(rate) {
        return '★'.repeat(rate) + '☆'.repeat(5 - rate);
    }

    return (
        <div className="mt-4">
            <h4>Отзывы</h4>
            
            <Card className="mb-3">
                <Card.Body>
                    <Card.Title>Оставить отзыв</Card.Title>
                    
                    {success && <Alert variant="success">{success}</Alert>}
                    
                    <Form.Group className="mb-3">
                        <Form.Label>Оценка</Form.Label>
                        <Form.Select value={rating} onChange={(e) => setRating(Number(e.target.value))}>
                            {[5,4,3,2,1].map(num => (
                                <option key={num} value={num}>{num} звезд</option>
                            ))}
                        </Form.Select>
                    </Form.Group>
                    
                    <Form.Group className="mb-3">
                        <Form.Label>Комментарий</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={3}
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                        />
                    </Form.Group>
                    
                    <Button 
                        variant="primary" 
                        onClick={() => addReview()}
                        disabled={isPending}
                    >
                        {isPending ? 'Отправка...' : 'Отправить'}
                    </Button>
                </Card.Body>
            </Card>
            
            {reviews.map(review => (
                <Card key={review.id} className="mb-2">
                    <Card.Body>
                        <div className="d-flex justify-content-between">
                            <div>
                                <strong>{review.user?.name}</strong>
                                <div className="text-warning">
                                    {renderStars(review.rating)}
                                </div>
                            </div>
                            <small className="text-muted">
                                {new Date(review.date).toLocaleDateString()}
                            </small>
                        </div>
                        <p className="mt-2">{review.comment}</p>
                    </Card.Body>
                </Card>
            ))}
            
            {reviews.length === 0 && (
                <p className="text-muted">Пока нет отзывов</p>
            )}
        </div>
    );
}

export default ReviewList;