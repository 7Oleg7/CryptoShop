import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Table, Button, Form } from 'react-bootstrap';
import { useCart } from '../hooks/useCart';

function Cart() {
    const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();
    const navigate = useNavigate();

    if (cartItems.length === 0) {
        return (
            <Container className="text-center mt-5">
                <h3>Корзина пуста</h3>
                <Button variant="primary" onClick={() => navigate('/')}>
                    Продолжить покупки
                </Button>
            </Container>
        );
    }

    return (
        <Container className="mt-4">
            <h2>Корзина</h2>
            
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Товар</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Сумма</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {cartItems.map(item => (
                        <tr key={item.product.id}>
                            <td>{item.product.name}</td>
                            <td>${item.product.price}</td>
                            <td>
                                <Form.Control
                                    type="number"
                                    min="1"
                                    value={item.quantity}
                                    onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value))}
                                    style={{ width: '80px' }}
                                />
                            </td>
                            <td>${(item.product.price * item.quantity).toFixed(2)}</td>
                            <td>
                                <Button variant="danger" size="sm" onClick={() => removeFromCart(item.product.id)}>
                                    Удалить
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            
            <div className="d-flex justify-content-between align-items-center">
                <h3>Итого: ${getCartTotal().toFixed(2)}</h3>
                <div>
                    <Button variant="secondary" className="me-2" onClick={() => navigate('/')}>
                        Продолжить покупки
                    </Button>
                    <Button variant="success" onClick={() => navigate('/checkout')}>
                        Оформить заказ
                    </Button>
                </div>
            </div>
        </Container>
    );
}

export default Cart;