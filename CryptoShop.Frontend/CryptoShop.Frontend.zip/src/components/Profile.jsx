import React, { useState } from 'react';
import { Container, Row, Col, Card, Table, Button, Form, Alert } from 'react-bootstrap';
import { useAuth } from '../hooks/useAuth';
import { useQuery, useMutation } from '@tanstack/react-query';
import axios from 'axios';

function Profile() {
    const { user, updateProfile, logout } = useAuth();
    
    const [isEditing, setIsEditing] = useState(false);
    const [name, setName] = useState(user?.name || '');
    const [phone, setPhone] = useState(user?.phone || '');
    const [address, setAddress] = useState(user?.address || '');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const { data: orders = [] } = useQuery({
        queryKey: ['orders', user?.id],
        queryFn: async () => {
            const response = await axios.get('http://localhost:5082/api/orders/user/' + user.id);
            return response.data;
        },
        enabled: !!user?.id
    });

    const { mutate: updateUser } = useMutation({
        mutationFn: async () => {
            if (newPassword && newPassword !== confirmPassword) {
                throw new Error('Пароли не совпадают');
            }
            const result = await updateProfile(user.id, { name, phone, address, newPassword });
            if (!result.success) throw new Error(result.error);
            return result;
        },
        onSuccess: () => {
            setSuccess('Профиль обновлен');
            setIsEditing(false);
            setNewPassword('');
            setConfirmPassword('');
            setTimeout(() => setSuccess(''), 3000);
        },
        onError: (err) => {
            setError(err.message);
            setTimeout(() => setError(''), 3000);
        }
    });

    function getStatusBadge(status) {
        const colors = {
            'Completed': 'success',
            'Paid': 'info',
            'Shipped': 'primary',
            'New': 'warning'
        };
        return colors[status] || 'secondary';
    }

    return (
        <Container className="mt-4">
            <h2>Мой профиль</h2>
            
            <Row>
                <Col md={4}>
                    <Card>
                        <Card.Body>
                            <Card.Title>Личные данные</Card.Title>
                            
                            {!isEditing ? (
                                <>
                                    <p><strong>Имя:</strong> {user.name}</p>
                                    <p><strong>Email:</strong> {user.email}</p>
                                    <p><strong>Телефон:</strong> {user.phone || 'не указан'}</p>
                                    <p><strong>Адрес:</strong> {user.address || 'не указан'}</p>
                                    
                                    <Button variant="primary" onClick={() => setIsEditing(true)}>
                                        Редактировать
                                    </Button>
                                    <Button variant="danger" className="ms-2" onClick={logout}>
                                        Выйти
                                    </Button>
                                </>
                            ) : (
                                <>
                                    {error && <Alert variant="danger">{error}</Alert>}
                                    {success && <Alert variant="success">{success}</Alert>}
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Имя</Form.Label>
                                        <Form.Control
                                            type="text"
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                        />
                                    </Form.Group>
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Телефон</Form.Label>
                                        <Form.Control
                                            type="text"
                                            value={phone}
                                            onChange={(e) => setPhone(e.target.value)}
                                        />
                                    </Form.Group>
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Адрес</Form.Label>
                                        <Form.Control
                                            type="text"
                                            value={address}
                                            onChange={(e) => setAddress(e.target.value)}
                                        />
                                    </Form.Group>
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Новый пароль</Form.Label>
                                        <Form.Control
                                            type="password"
                                            value={newPassword}
                                            onChange={(e) => setNewPassword(e.target.value)}
                                        />
                                    </Form.Group>
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Подтвердите пароль</Form.Label>
                                        <Form.Control
                                            type="password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                        />
                                    </Form.Group>
                                    
                                    <Button variant="success" onClick={() => updateUser()}>
                                        Сохранить
                                    </Button>
                                    <Button variant="secondary" className="ms-2" onClick={() => {
                                        setIsEditing(false);
                                        setName(user.name);
                                        setPhone(user.phone);
                                        setAddress(user.address);
                                        setNewPassword('');
                                        setConfirmPassword('');
                                    }}>
                                        Отмена
                                    </Button>
                                </>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
                
                <Col md={8}>
                    <Card>
                        <Card.Body>
                            <Card.Title>История заказов</Card.Title>
                            
                            {orders.length === 0 ? (
                                <p className="text-muted">У вас пока нет заказов</p>
                            ) : (
                                <Table striped bordered hover>
                                    <thead>
                                        <tr>
                                            <th>№ заказа</th>
                                            <th>Дата</th>
                                            <th>Сумма</th>
                                            <th>Статус</th>
                                            <th>Товары</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {orders.map(order => (
                                            <tr key={order.id}>
                                                <td>{order.orderNumber}</td>
                                                <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                                                <td>${order.totalAmount}</td>
                                                <td>
                                                    <span className={`badge bg-${getStatusBadge(order.status)}`}>
                                                        {order.status}
                                                    </span>
                                                </td>
                                                <td>
                                                    {order.items?.map(item => (
                                                        <div key={item.id}>
                                                            {item.product?.name} x {item.quantity}
                                                        </div>
                                                    ))}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            )}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default Profile;