import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Form, Button, Spinner } from 'react-bootstrap';
import useProducts from '../hooks/useProducts';

function ProductList() {
    const { products, isLoading } = useProducts();

    const [selectedCategory, setSelectedCategory] = useState('');
    const [minPrice, setMinPrice] = useState('');
    const [maxPrice, setMaxPrice] = useState('');
    const [searchText, setSearchText] = useState('');
    
    const categories = [...new Set(products.map(p => p.categoryName).filter(Boolean))];
    
    function getFilteredProducts() {
        let filtered = products;

        if (selectedCategory) {
            filtered = filtered.filter(p => p.categoryName === selectedCategory);
        }

        if (minPrice) {
            filtered = filtered.filter(p => p.price >= Number(minPrice));
        }

        if (maxPrice) {
            filtered = filtered.filter(p => p.price <= Number(maxPrice));
        }

        if (searchText) {
            filtered = filtered.filter(p => 
                p.name.toLowerCase().includes(searchText.toLowerCase())
            );
        }

        return filtered;
    }

    function resetFilters() {
        setSelectedCategory('');
        setMinPrice('');
        setMaxPrice('');
        setSearchText('');
    }

    if (isLoading) {
        return (
            <div className="text-center mt-5">
                <Spinner animation="border" variant="primary" />
                <p className="mt-2">Загрузка товаров...</p>
            </div>
        );
    }

    const filteredProducts = getFilteredProducts();

    return (
        <Container fluid className="mt-4 px-4">
            <h2 className="mb-4">Товары</h2>
            
            <Card className="mb-4">
                <Card.Body>
                    <Row>
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Категория</Form.Label>
                                <Form.Select 
                                    value={selectedCategory} 
                                    onChange={(e) => setSelectedCategory(e.target.value)}
                                >
                                    <option value="">Все категории</option>
                                    {categories.map(cat => (
                                        <option key={cat} value={cat}>{cat}</option>
                                    ))}
                                </Form.Select>
                            </Form.Group>
                        </Col>
                        
                        <Col md={2}>
                            <Form.Group>
                                <Form.Label>Цена от</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={minPrice}
                                    onChange={(e) => setMinPrice(e.target.value)}
                                    min="0"
                                />
                            </Form.Group>
                        </Col>
                        
                        <Col md={2}>
                            <Form.Group>
                                <Form.Label>Цена до</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={maxPrice}
                                    onChange={(e) => setMaxPrice(e.target.value)}
                                    min="0"
                                />
                            </Form.Group>
                        </Col>
                        
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Поиск</Form.Label>
                                <Form.Control
                                    type="text"
                                    value={searchText}
                                    onChange={(e) => setSearchText(e.target.value)}
                                    placeholder="Название товара..."
                                />
                            </Form.Group>
                        </Col>
                        
                        <Col md={2} className="d-flex align-items-end">
                            <Button variant="secondary" onClick={resetFilters}>
                                Сброс
                            </Button>
                        </Col>
                    </Row>
                </Card.Body>
            </Card>
            
            <Row>
                {filteredProducts.map(product => (
                    <Col key={product.id} md={3} className="mb-4">
                        <Card className="h-100">
                            <Card.Img 
                                variant="top" 
                                src={product.imageUrl || 'https://via.placeholder.com/200'} 
                                style={{ height: '200px', objectFit: 'cover' }}
                            />
                            <Card.Body>
                                <Card.Title>{product.name}</Card.Title>
                                <Card.Text>
                                    <strong className="text-success">${product.price}</strong>
                                    <br />
                                    <small className="text-muted">{product.categoryName}</small>
                                </Card.Text>
                                <Link to={`/product/${product.id}`}>
                                    <Button variant="primary" size="sm">Подробнее</Button>
                                </Link>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
            
            {filteredProducts.length === 0 && (
                <p className="text-center">Товары не найдены</p>
            )}
        </Container>
    );
}

export default ProductList;