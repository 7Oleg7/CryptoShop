import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Container, Badge, Button } from 'react-bootstrap';
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';

function Navigation() {
    const { user, logout } = useAuth();
    const { getCartCount } = useCart();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <Navbar bg="dark" variant="dark" expand="lg" className="w-100" style={{ width: '100%' }}>
            <Container fluid style={{ maxWidth: '100%', paddingLeft: '20px', paddingRight: '20px' }}>
                <Navbar.Brand as={Link} to="/">CryptoShop</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link as={Link} to="/">Товары</Nav.Link>
                        {user && user.role === 'Admin' && (
                            <Nav.Link as={Link} to="/admin">Админка</Nav.Link>
                        )}
                    </Nav>
                    <Nav>
                        <Nav.Link as={Link} to="/cart" className="d-flex align-items-center">
                            Корзина 
                            {getCartCount() > 0 && (
                                <Badge bg="danger" className="ms-1">{getCartCount()}</Badge>
                            )}
                        </Nav.Link>
                        {user ? (
                            <>
                                <Nav.Link as={Link} to="/profile">{user.name}</Nav.Link>
                                <Button variant="outline-light" size="sm" onClick={handleLogout}>
                                    Выйти
                                </Button>
                            </>
                        ) : (
                            <>
                                <Nav.Link as={Link} to="/login">Вход</Nav.Link>
                                <Nav.Link as={Link} to="/register">Регистрация</Nav.Link>
                            </>
                        )}
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default Navigation;