import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Form, Button, Table, Tabs, Tab, Alert } from 'react-bootstrap';
import { useAuth } from '../hooks/useAuth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

function AdminDashboard() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [activeTab, setActiveTab] = useState('products');
    const [newProduct, setNewProduct] = useState({
        name: '', price: '', description: '', stock: '', categoryId: 1
    });

    const categories = [
        { id: 1, name: 'Electronics' },
        { id: 2, name: 'Clothing' },
        { id: 3, name: 'Books' }
    ];

    const { data: products = [] } = useQuery({
        queryKey: ['products'],
        queryFn: async () => {
            const response = await axios.get('http://localhost:5082/api/products');
            return response.data;
        },
        enabled: user?.role === 'Admin'
    });

    const { mutate: addProduct } = useMutation({
        mutationFn: async () => {
            await axios.post('http://localhost:5082/api/products', {
                name: newProduct.name,
                price: Number(newProduct.price),
                description: newProduct.description,
                stock: Number(newProduct.stock),
                categoryId: newProduct.categoryId
            }, { headers: { 'X-User-Role': 'Admin' } });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
            setNewProduct({ name: '', price: '', description: '', stock: '', categoryId: 1 });
            alert('Товар добавлен');
        }
    });

    const { mutate: deleteProduct } = useMutation({
        mutationFn: async (id) => {
            await axios.delete('http://localhost:5082/api/products/' + id, {
                headers: { 'X-User-Role': 'Admin' }
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
        }
    });

    if (user?.role !== 'Admin') {
        navigate('/');
        return null;
    }

    return (
        <Container className="mt-4">
            <h2>Панель администратора</h2>
            
            <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k)} className="mb-4">
                <Tab eventKey="products" title="Товары">
                    <Row>
                        <Col md={4}>
                            <Card>
                                <Card.Body>
                                    <Card.Title>Добавить товар</Card.Title>
                                    <Form>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Название</Form.Label>
                                            <Form.Control
                                                type="text"
                                                value={newProduct.name}
                                                onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                                            />
                                        </Form.Group>
                                        
                                        <Form.Group className="mb-3">
                                            <Form.Label>Цена</Form.Label>
                                            <Form.Control
                                                type="number"
                                                value={newProduct.price}
                                                onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                                            />
                                        </Form.Group>
                                        
                                        <Form.Group className="mb-3">
                                            <Form.Label>Количество</Form.Label>
                                            <Form.Control
                                                type="number"
                                                value={newProduct.stock}
                                                onChange={(e) => setNewProduct({...newProduct, stock: e.target.value})}
                                            />
                                        </Form.Group>
                                        
                                        <Form.Group className="mb-3">
                                            <Form.Label>Категория</Form.Label>
                                            <Form.Select
                                                value={newProduct.categoryId}
                                                onChange={(e) => setNewProduct({...newProduct, categoryId: Number(e.target.value)})}
                                            >
                                                {categories.map(cat => (
                                                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                                                ))}
                                            </Form.Select>
                                        </Form.Group>
                                        
                                        <Form.Group className="mb-3">
                                            <Form.Label>Описание</Form.Label>
                                            <Form.Control
                                                as="textarea"
                                                rows={3}
                                                value={newProduct.description}
                                                onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                                            />
                                        </Form.Group>
                                        
                                        <Button variant="success" onClick={() => addProduct()}>
                                            Добавить товар
                                        </Button>
                                    </Form>
                                </Card.Body>
                            </Card>
                        </Col>
                        
                        <Col md={8}>
                            <Card>
                                <Card.Body>
                                    <Card.Title>Все товары</Card.Title>
                                    <Table striped bordered hover>
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Название</th>
                                                <th>Цена</th>
                                                <th>В наличии</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {products.map(item => (
                                                <tr key={item.id}>
                                                    <td>{item.id}</td>
                                                    <td>{item.name}</td>
                                                    <td>${item.price}</td>
                                                    <td>{item.stock}</td>
                                                    <td>
                                                        <Button 
                                                            variant="danger" 
                                                            size="sm"
                                                            onClick={() => {
                                                                if (window.confirm('Удалить товар?')) {
                                                                    deleteProduct(item.id);
                                                                }
                                                            }}
                                                        >
                                                            Удалить
                                                        </Button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </Table>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </Tab>
                
                <Tab eventKey="orders" title="Заказы">
                    <Card>
                        <Card.Body>
                            <Card.Title>Заказы</Card.Title>
                            <p className="text-muted">Нет заказов</p>
                        </Card.Body>
                    </Card>
                </Tab>
                
                <Tab eventKey="users" title="Пользователи">
                    <Card>
                        <Card.Body>
                            <Card.Title>Пользователи</Card.Title>
                            <p className="text-muted">Нет пользователей</p>
                        </Card.Body>
                    </Card>
                </Tab>
            </Tabs>
        </Container>
    );
}

export default AdminDashboard;